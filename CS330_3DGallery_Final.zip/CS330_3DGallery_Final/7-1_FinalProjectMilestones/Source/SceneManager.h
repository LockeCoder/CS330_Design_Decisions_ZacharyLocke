///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ================
// Manages loading, transforming, and rendering the 3D scene.
//
//  AUTHOR:  Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//  STUDENT: Zachary Locke � lighting, materials, textures, and scene layout
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <glm/glm.hpp>
#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  Coordinates shader state, geometry, materials, textures,
 *  and lights for the 3D scene.  PrepareScene() loads
 *  everything needed; RenderScene() draws the final view.
 ***********************************************************/
class SceneManager
{
public:
    // Constructor / destructor
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    /***********************************************************
     *  OBJECT_MATERIAL
     *
     *  Phong material description used by the lighting shader.
     *  Each object can select a material by tag.
     ***********************************************************/
    struct OBJECT_MATERIAL
    {
        float       ambientStrength;   // overall ambient factor
        glm::vec3   ambientColor;      // ambient light color
        glm::vec3   diffuseColor;      // base surface color
        glm::vec3   specularColor;     // highlight color
        float       shininess;         // specular size/intensity
        std::string tag;               // lookup name (e.g., "defaultWhite")
    };

private:
    // Pointer to shader manager helper (owns shader program)
    ShaderManager* m_pShaderManager;

    // Pointer to reusable mesh collection (box, plane, cone, etc.)
    ShapeMeshes* m_basicMeshes;

    // List of all defined materials for this scene
    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // ------------------------------------------------------------------
    // Texture bookkeeping � one ID per major textured object group
    // ------------------------------------------------------------------
// Texture bookkeeping � one ID per major textured object group
    unsigned int m_floorTexID = 0;  // tilesf2.jpg  (or stainless, etc.)
    unsigned int m_wallTexID = 0;  // drywall.jpg
    unsigned int m_goldColumnTexID = 0;  // gold-seamless-texture.jpg
    unsigned int m_steelColumnTexID = 0;  // stainless.jpg
    unsigned int m_sphereTexID = 0;  // stainless_end.jpg
    unsigned int m_abstractTexID = 0;  // abstract.jpg


    /***********************************************************
     *  Texture helpers
     ***********************************************************/
     // Load all textures used in the gallery scene
    void         LoadSceneTextures();

    // Load a single 2D texture from disk and return its OpenGL ID
    unsigned int LoadTexture2D(const char* filePath);

    // Bind a specific texture and tell the shader to sample it
    void         UseTexture(unsigned int textureID);

    /***********************************************************
     *  Material and lighting helpers
     ***********************************************************/
     // Look up a defined material by its tag
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

    // Define all object materials used in the scene
    void DefineObjectMaterials();

    // Configure Phong light sources for the scene
    void SetupSceneLights();

    /***********************************************************
     *  Shader / transform helpers
     ***********************************************************/
     // Build model matrix from scale / rotation / position and
     // send it to the shader uniform "model".
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float     XrotationDegrees,
        float     YrotationDegrees,
        float     ZrotationDegrees,
        glm::vec3 positionXYZ);

    // Set a solid vertex color in the shader.
    // NOTE: this does NOT change the bUseTexture flag; you can
    // combine a color tint with a texture or use flat color only.
    void SetShaderColor(
        float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);

    // Apply a named material�s Phong values in the shader
    void SetShaderMaterial(std::string materialTag);

public:
    /***********************************************************
     *  High-level scene control (student-customizable)
     ***********************************************************/
     // Load meshes, textures, materials, and lights needed
     // for the final project scene.
    void PrepareScene();

    // Render the full 3D �gallery display� scene.
    void RenderScene();
};
