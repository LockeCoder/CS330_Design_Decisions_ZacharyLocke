///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// Manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>   // for perspective / ortho

// ------------------ file-local state ------------------
namespace
{
    // Window + uniform names
    const int   WINDOW_WIDTH = 1000;
    const int   WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    // Camera used for viewing / interacting with the 3D scene
    Camera* g_pCamera = nullptr;

    // Mouse movement tracking
    float gLastX = WINDOW_WIDTH * 0.5f;
    float gLastY = WINDOW_HEIGHT * 0.5f;
    bool  gFirstMouse = true;

    // Per-frame timing
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // Projection mode
    bool  bOrthographicProjection = false;

    // Ortho box size (half-height). Scroll wheel will adjust this.
    float       gOrthoHalfH = 6.0f;   // default zoom
    const float gOrthoMinHalfH = 2.0f;
    const float gOrthoMaxHalfH = 30.0f;

    // Movement speed control in 3D, tuned via scroll wheel
    float gScrollSpeedStep = 2.0f;
    float gMinSpeed = 2.0f;
    float gMaxSpeed = 40.0f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    // initialize the member variables
    m_pShaderManager = pShaderManager;
    m_pWindow = nullptr;

    g_pCamera = new Camera();

    // Default camera view parameters
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80.0f;

    // Navigation tuning (Final Project: navigation criteria)
    g_pCamera->MovementSpeed = 12.0f;   // WASD/QE speed
    g_pCamera->MouseSensitivity = 0.35f;   // smooth mouse look
}

/***********************************************************
 *  ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
    // free up allocated memory
    m_pShaderManager = nullptr;
    m_pWindow = nullptr;

    if (g_pCamera != nullptr)
    {
        delete g_pCamera;
        g_pCamera = nullptr;
    }
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = nullptr;

    // try to create the displayed OpenGL window
    window = glfwCreateWindow(
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        windowTitle,
        NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }
    glfwMakeContextCurrent(window);

    // Optional: capture mouse cursor
    // glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Mouse movement + scroll callbacks
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Wheel_Callback);

    // Enable blending for supporting transparent rendering
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Called by GLFW whenever the mouse is moved
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* /*window*/, double xMousePos, double yMousePos)
{
    // In orthographic mode we keep the camera fixed: no mouse-look
    if (bOrthographicProjection || !g_pCamera) return;

    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset = static_cast<float>(xMousePos) - gLastX;
    float yOffset = gLastY - static_cast<float>(yMousePos);  // reversed since y-coordinates go from bottom to top

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    // Camera applies MouseSensitivity internally
    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Wheel_Callback()
 *
 *  Called by GLFW whenever the scroll wheel is moved
 ***********************************************************/
void ViewManager::Mouse_Scroll_Wheel_Callback(GLFWwindow* /*window*/, double /*xOffset*/, double yOffset)
{
    if (!g_pCamera) return;

    if (bOrthographicProjection)
    {
        // In 2D: scroll zooms the ortho box (rubric: perspective/orthographic displays)
        float scale = (yOffset > 0.0) ? 0.9f : 1.1f;
        gOrthoHalfH = glm::clamp(gOrthoHalfH * scale, gOrthoMinHalfH, gOrthoMaxHalfH);
    }
    else
    {
        // In 3D: scroll adjusts movement speed (rubric: nuanced camera controls)
        g_pCamera->MovementSpeed += static_cast<float>(yOffset) * gScrollSpeedStep;
        g_pCamera->MovementSpeed = glm::clamp(g_pCamera->MovementSpeed, gMinSpeed, gMaxSpeed);

        // If you ever want scroll to zoom FOV instead, you could also call:
        // g_pCamera->ProcessMouseScroll(static_cast<float>(yOffset));
    }
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Process any keyboard events waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
    // Close the window with ESC
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    // If there is no camera yet, stop here
    if (!g_pCamera)
        return;

    // --- Navigation: WASD + Q/E for X, Y, Z movement ---
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);

    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);

    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);

    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);

    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);

    // ============================
    // Projection mode (rubric item 7)
    // Toggle perspective / orthographic with P
    // ============================
    static bool lastPState = false;
    bool pPressed = (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS);

    if (pPressed && !lastPState)
    {
        bOrthographicProjection = !bOrthographicProjection;
        gFirstMouse = true;          // reset mouse deltas whenever mode changes
    }

    lastPState = pPressed;

    // Optional: while in orthographic, reset zoom with R
    if (bOrthographicProjection &&
        glfwGetKey(m_pWindow, GLFW_KEY_R) == GLFW_PRESS)
    {
        gOrthoHalfH = 6.0f;          // default ortho half-height
    }
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Prepare the 3D scene view/projection each frame
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    // per-frame timing
    float currentFrame = glfwGetTime();
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    ProcessKeyboardEvents();

    view = g_pCamera->GetViewMatrix();

    float aspect = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;

    if (bOrthographicProjection)
    {
        // simple ortho box around the sculpture
        float halfH = gOrthoHalfH;          // e.g. 6.0f
        float halfW = halfH * aspect;
        projection = glm::ortho(-halfW, halfW,
            -halfH, halfH,
            0.1f, 100.0f);
    }
    else
    {
        // normal 3D, slightly zoomed in
        projection = glm::perspective(glm::radians(g_pCamera->Zoom),
            aspect,
            0.1f, 100.0f);
    }

    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}