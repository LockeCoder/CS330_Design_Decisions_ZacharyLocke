﻿///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ================
// Manages loading, transforming, and rendering the 3D scene for the project.
// This file also configures the Phong-based lighting model and object
// materials, which are the focus of Milestone Five (lighting and shaders).
//
//  AUTHOR:  Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//  STUDENT: Zachary Locke – lighting, materials, textures, and scene layout
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include <glm/gtx/transform.hpp>
#include <GL/glew.h>
#include "stb_image.h"
#include <iostream>

// Shader uniform names used throughout this file
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;

    if (m_basicMeshes != NULL)
    {
        delete m_basicMeshes;
        m_basicMeshes = NULL;
    }

    m_objectMaterials.clear();
}

/***********************************************************
 *  LoadTexture2D()
 ***********************************************************/
unsigned int SceneManager::LoadTexture2D(const char* filePath)
{
    unsigned int textureID = 0;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // Basic wrap + filter
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    int width = 0, height = 0, nrChannels = 0;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* data = stbi_load(filePath, &width, &height, &nrChannels, 0);

    if (data)
    {
        GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;

        glTexImage2D(GL_TEXTURE_2D,
            0,
            format,
            width,
            height,
            0,
            format,
            GL_UNSIGNED_BYTE,
            data);

        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cerr << "Failed to load texture: " << filePath << std::endl;
        glDeleteTextures(1, &textureID);
        textureID = 0;
    }

    stbi_image_free(data);
    return textureID;
}

/***********************************************************
 *  UseTexture()
 ***********************************************************/
void SceneManager::UseTexture(unsigned int textureID)
{
    if (!m_pShaderManager || textureID == 0)
        return;

    m_pShaderManager->use();
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureID);

    m_pShaderManager->setBoolValue(g_UseTextureName, true);
    m_pShaderManager->setIntValue(g_TextureValueName, 0);
}

/***********************************************************
 *  LoadSceneTextures()
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    m_floorTexID = LoadTexture2D("Assets/stainless.jpg");         
    m_wallTexID = LoadTexture2D("Assets/drywall.jpg");
    m_goldColumnTexID = LoadTexture2D("Assets/gold-seamless-texture.jpg");
    m_steelColumnTexID = LoadTexture2D("Assets/stainless.jpg");
    m_sphereTexID = LoadTexture2D("Assets/stainless_end.jpg");
    m_abstractTexID = LoadTexture2D("Assets/abstract.jpg");
}


/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.empty())
    {
        return false;
    }

    bool bFound = false;
    int  index = 0;

    while ((index < static_cast<int>(m_objectMaterials.size())) && !bFound)
    {
        if (m_objectMaterials[index].tag == tag)
        {
            bFound = true;
            material.ambientColor = m_objectMaterials[index].ambientColor;
            material.ambientStrength = m_objectMaterials[index].ambientStrength;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            ++index;
        }
    }

    return bFound;
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float     XrotationDegrees,
    float     YrotationDegrees,
    float     ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 *
 *  IMPORTANT: This version does NOT change bUseTexture.
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue,
        greenColorValue,
        blueColorValue,
        alphaValue);

    if (m_pShaderManager)
    {
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (!m_objectMaterials.empty())
    {
        OBJECT_MATERIAL material;
        if (FindMaterial(materialTag, material))
        {
            m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
            m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Softer, less reflective material so the floor and objects
 *  don’t blow out under the lights.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    // remove any previously stored material definitions
    m_objectMaterials.clear();

    OBJECT_MATERIAL baseMat;
    baseMat.tag = "defaultWhite";

    // darker ambient overall
    baseMat.ambientColor = glm::vec3(0.30f, 0.30f, 0.30f);
    baseMat.ambientStrength = 0.02f;

    // slightly brighter diffuse, but not pure white
    baseMat.diffuseColor = glm::vec3(0.80f, 0.80f, 0.80f);

    // weaker specular so highlights aren’t harsh
    baseMat.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
    baseMat.shininess = 16.0f;   // tighter but softer highlight

    m_objectMaterials.push_back(baseMat);

    // send the default material to the shader
    if (m_pShaderManager)
    {
        m_pShaderManager->use();
        m_pShaderManager->setVec3Value("material.ambientColor",
            baseMat.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength",
            baseMat.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor",
            baseMat.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor",
            baseMat.specularColor);
        m_pShaderManager->setFloatValue("material.shininess",
            baseMat.shininess);
    }
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Very soft lighting:
 *    • Light 0: single gentle key above/front
 *    • Lights 1–3: disabled
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    if (!m_pShaderManager)
        return;

    m_pShaderManager->use();
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // -------- Light 0: SOFT KEY (above / in front) --------
    m_pShaderManager->setVec3Value("lightSources[0].position",
        2.0f, 4.0f, 4.0f);

    // very low ambient, modest diffuse, weak specular
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor",
        0.01f, 0.01f, 0.01f);
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor",
        0.22f, 0.22f, 0.24f);
    m_pShaderManager->setVec3Value("lightSources[0].specularColor",
        0.35f, 0.35f, 0.35f);

    // keep these low so the hotspot doesn’t blow out
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 3.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.18f);

    // -------- Lights 1, 2, 3: DISABLED --------
    for (int i = 1; i < 4; ++i)
    {
        std::string base = "lightSources[" + std::to_string(i) + "].";
        m_pShaderManager->setVec3Value(base + "ambientColor", 0.0f, 0.0f, 0.0f);
        m_pShaderManager->setVec3Value(base + "diffuseColor", 0.0f, 0.0f, 0.0f);
        m_pShaderManager->setVec3Value(base + "specularColor", 0.0f, 0.0f, 0.0f);
        m_pShaderManager->setFloatValue(base + "focalStrength", 1.0f);
        m_pShaderManager->setFloatValue(base + "specularIntensity", 0.0f);
    }
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
    DefineObjectMaterials();
    SetupSceneLights();
    LoadSceneTextures();   // floor, wall, gold, steel, sphere textures

    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
    if (m_pShaderManager)
    {
        m_pShaderManager->setBoolValue(g_UseLightingName, true);
    }

    glm::vec3 scaleXYZ;
    float     XrotationDegrees = 0.0f;
    float     YrotationDegrees = 0.0f;
    float     ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    /**********************
     * FLOOR  (tiles)
     **********************/
    scaleXYZ = glm::vec3(18.0f, 1.0f, 12.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

    SetTransformations(scaleXYZ, XrotationDegrees, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_steelColumnTexID);
    SetShaderColor(0.55f, 0.55f, 0.60f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();

    /**********************
     * BACK WALL (drywall)
     **********************/
    scaleXYZ = glm::vec3(18.0f, 1.0f, 8.0f);
    XrotationDegrees = -90.0f;                        // stand it up
    positionXYZ = glm::vec3(0.0f, 6.0f, -6.0f);

    SetTransformations(scaleXYZ, XrotationDegrees, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_wallTexID);                          // drywall.jpg
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();

    /**********************
     * LEFT TALL COLUMN (gold)
     **********************/
    scaleXYZ = glm::vec3(0.9f, 6.0f, 0.9f);
    positionXYZ = glm::vec3(-6.0f, 0.0f, -1.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_goldColumnTexID);                    // gold texture
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    /**********************
     * LEFT MID COLUMN (steel)
     **********************/
    scaleXYZ = glm::vec3(0.6f, 4.0f, 0.6f);
    positionXYZ = glm::vec3(-3.0f, 0.0f, -1.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_steelColumnTexID);                   // stainless
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    /**********************
     * RIGHT MID COLUMN (steel)
     **********************/
    scaleXYZ = glm::vec3(0.6f, 4.0f, 0.6f);
    positionXYZ = glm::vec3(3.0f, 0.0f, -1.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_steelColumnTexID);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    /**********************
     * RIGHT TALL COLUMN (gold)
     **********************/
    scaleXYZ = glm::vec3(0.9f, 6.0f, 0.9f);
    positionXYZ = glm::vec3(6.0f, 0.0f, -1.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_goldColumnTexID);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    /**********************
     * FRONT CONE (solid blue, no texture)
     **********************/
    scaleXYZ = glm::vec3(1.4f, 2.8f, 1.4f);
    positionXYZ = glm::vec3(-3.8f, 0.0f, 3.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    if (m_pShaderManager)
        m_pShaderManager->setBoolValue(g_UseTextureName, false);

    SetShaderColor(0.12f, 0.20f, 0.60f, 1.0f);
    m_basicMeshes->DrawConeMesh();

    // CENTER PEDESTAL BOX (abstract texture)
    scaleXYZ = glm::vec3(2.0f, 0.6f, 2.0f);
    positionXYZ = glm::vec3(0.0f, 0.3f, 1.0f);
    SetTransformations(scaleXYZ, 0.0f, 10.0f, 0.0f, positionXYZ);
    UseTexture(m_abstractTexID);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

    m_basicMeshes->DrawBoxMesh();

    /**********************
     * SMALL STAND CYLINDER (gold texture)
     **********************/
    scaleXYZ = glm::vec3(0.7f, 1.0f, 0.7f);
    positionXYZ = glm::vec3(0.0f, 0.8f, 1.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_goldColumnTexID);                    // makes the stand gold
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    /**********************
     * SPHERE “SCULPTURE” (sphere texture)
     **********************/
    scaleXYZ = glm::vec3(1.4f, 1.4f, 1.4f);
    positionXYZ = glm::vec3(0.0f, 2.0f, 1.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    UseTexture(m_sphereTexID);                       // e.g., stainedglass
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    m_basicMeshes->DrawSphereMesh();
}