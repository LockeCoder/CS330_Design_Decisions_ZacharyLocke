#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include <GLFW/glfw3.h>

class ViewManager
{
public:
    // constructor / destructor
    ViewManager(ShaderManager* pShaderManager);
    ~ViewManager();

    // Mouse position callback (look around)
    static void Mouse_Position_Callback(GLFWwindow* window,
        double xMousePos,
        double yMousePos);

    // Mouse scroll callback (speed / ortho zoom)
    static void Mouse_Scroll_Wheel_Callback(GLFWwindow* window,
        double xOffset,
        double yOffset);

    // Create initial OpenGL window
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Prepare view/projection for each frame
    void PrepareSceneView();

private:
    ShaderManager* m_pShaderManager;
    GLFWwindow* m_pWindow;

    void ProcessKeyboardEvents();
};